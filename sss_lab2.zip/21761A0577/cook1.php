<?php
setcookie("branch","CSE",time()+3600,"/","",0);
setcookie("code","05",time()+3600,"/","",0);

echo "The cookies created for branch and code. ";
?>
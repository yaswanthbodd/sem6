<?php
include("links.html");
include("db.php");
$count=0;
$un=$_POST['utf'];
$pwd=$_POST['ptf'];
$sql="SELECT * FROM stud_info";
$result = mysqli_query($conn,$sql);
#It checks the database
while($row=mysqli_fetch_assoc($result)){
    if($un==$row['sname'] && $pwd==$row['password']){
        setcookie("user",$un,time()+3600,"/","",0);
        $count++;
        ?>
        <script>
            alert("Succesfully Login");
        </script>
        <?php
        break;
    }else{
        continue;
    }
}
if($count==0){
    ?>
    <script>
        alert("Invalid Username or Password");
    </script>
    <?php
    include("login.html");
}
?>
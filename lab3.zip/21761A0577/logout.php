<?php
include("links.html");
echo "<br><br>";
    setcookie("user",$un,time()-3600,"/","",0);
    echo $un."Logout Successully..";
?>

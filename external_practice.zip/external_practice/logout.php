<a href="register.html">Register</a> | <a href="login.html">Login</a> | <a href="logout.php">Logout</a> | <a
        href="viewall.php">ViewAll</a> | <a href="update.html">Update</a> | <a href="delete.html">Delete</a>
    <br><br><br>
<?php
include("db.php");
$un=$_COOKIE['user'];
if(setcookie('user',$un,time()-3600,"/","",0)){
    echo "Logout Successfull...";
}else{
    echo "Login First..";
}

?>
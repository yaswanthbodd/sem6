<a href="register.html">Register</a> | <a href="login.html">Login</a> | <a href="logout.php">Logout</a> | <a
        href="viewall.php">ViewAll</a> | <a href="update.html">Update</a> | <a href="delete.html">Delete</a>
    <br><br><br>
<?php
include("db.php");
if(isset($_COOKIE['user'])){
$rtf=$_POST['rtf'];
$utf=$_POST['utf'];
$dtf=$_POST['dtf'];

$sql="UPDATE stud SET uname='$utf',dob='$dtf' WHERE regno='$rtf'";
if(mysqli_query($conn,$sql)){
    echo "Update Successfull...";
}else{
    echo "Not Successfull....";
}
}else{
    echo "Login First";
}
?>
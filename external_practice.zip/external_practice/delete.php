<a href="register.html">Register</a> | <a href="login.html">Login</a> | <a href="logout.php">Logout</a> | <a
        href="viewall.php">ViewAll</a> | <a href="update.html">Update</a> | <a href="delete.html">Delete</a>
    <br><br><br>

<?php
if(isset($_COOKIE['user'])){
    include("db.php");
$uname=$_POST['uname'];
$sql="DELETE FROM stud WHERE uname='$uname'";
if(mysqli_query($conn,$sql)){
    echo "<br>Deleted Successfull...";
    header("Location: viewall.php");
}else{
    echo "<br>Something FIshy...";
}
}else{
    echo "Login First";
}
?>
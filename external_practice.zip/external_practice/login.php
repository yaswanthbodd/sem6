<a href="register.html">Register</a> | <a href="login.html">Login</a> | <a href="logout.php">Logout</a> | <a
        href="viewall.php">ViewAll</a> | <a href="update.html">Update</a> | <a href="delete.html">Delete</a>
    <br><br><br>
<?php
include("db.php");
$un=$_POST['uname'];
$pw=$_POST['pwd'];
$sql="SELECT * FROM stud WHERE uname='$un'";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($result)){
    if($un==$row['uname'] && $pw==$row['password']){
        setcookie('user',$un,time()+3600,"/","",0);
        echo "Login Successfull..";
    }else{
        echo "Not Login...";
    }
}
?>
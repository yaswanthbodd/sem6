<a href="register.html">Register</a> | <a href="login.html">Login</a> | <a href="logout.php">Logout</a> | <a
        href="viewall.php">ViewAll</a> | <a href="update.html">Update</a> | <a href="delete.html">Delete</a>
    <br><br><br>

<?php
include("db.php");
if(isset($_COOKIE['user'])){
    $uname=$_POST['uname'];
    $sql="SELECT * FROM stud WHERE uname='$uname'";
    $result=mysqli_query($conn,$sql);

?>
<center>
    <form action="updt.php" method="post">
    <table border="5">
        <tr>
            <th>Register Number</th>
            <th>Name</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Course</th>
            <th>Operation</th>
        </tr>
        <tr>
    <?php
    while($row=mysqli_fetch_assoc($result)){
        ?>
        <td><input type="text" value=<?php echo $row['regno']; ?> name='rtf'></td>
        <td><input type="text" value=<?php echo $row['uname']; ?> name='utf'></td>
        <td><?php echo $row['gen']; ?></td>
        <td><input type="date" value=<?php echo $row['dob']; ?> name="dtf"></td>
        <td><?php echo $row['course']; ?></td>
        <td><input type="submit" value="submit"></td>
        </tr>
<?php
    }
  ?>  
    
</table>
</form>
</center>
<?php
}else{
    echo "<br><br>Login First....";
}

?>
<a href="register.html">Register</a> | <a href="login.html">Login</a> | <a href="logout.php">Logout</a> | <a
        href="viewall.php">ViewAll</a> | <a href="update.html">Update</a> | <a href="delete.html">Delete</a>
    <br><br><br>

<?php
include("db.php");
if(isset($_COOKIE['user'])){

    $sql="SELECT * FROM stud";
    $result=mysqli_query($conn,$sql);

?>
<center>
    <table border="5">
        <tr>
            <th>Register Number</th>
            <th>Name</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Course</th>
        </tr>
        <tr>
    <?php
    while($row=mysqli_fetch_assoc($result)){
        ?>
        <td><?php echo $row['regno']; ?></td>
        <td><?php echo $row['uname']; ?></td>
        <td><?php echo $row['gen']; ?></td>
        <td><?php echo $row['dob']; ?></td>
        <td><?php echo $row['course']; ?></td>
        </tr>
<?php
    }
  ?>  
    
</table>
</center>
<?php
}else{
    echo "<br><br>Login First....";
}

?>
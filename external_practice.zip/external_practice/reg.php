<a href="register.html">Register</a> | <a href="login.html">Login</a> | <a href="logout.php">Logout</a> | <a
        href="viewall.php">ViewAll</a> | <a href="update.html">Update</a> | <a href="delete.html">Delete</a>
    <br><br><br>
<?php
include("db.php");
$regno=$_POST['regno'];
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];
$gen=$_POST['gender'];
$dob=$_POST['dob'];
$cor=$_POST['course'];

$sql="INSERT INTO stud VALUES('$regno','$uname','$pwd','$gen','$dob','$cor')";

if(mysqli_query($conn,$sql)){
    echo "Inserted one Record";
}else{
    echo "NOt INserted..";
}
?>
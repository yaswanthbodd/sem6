<?php 
echo "welcome";

?>